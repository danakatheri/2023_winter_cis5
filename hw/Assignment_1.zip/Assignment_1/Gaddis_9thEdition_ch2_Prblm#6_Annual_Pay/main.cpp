
/* 
 * File:   main.cpp
 * Author: danak
 * Created on January 11, 2023, 5:05pm
 * Purpose: Annual Pay
 * 
 */
//System Lib

#include <iostream> //Input Output Library

using namespace std;

//User LIBRARIES
 
 //Global Constants not Variables

//Science, Math, Conversions, Dimensions

//Function Prototypes

//Execution begins here at main
int main(int argc, char** argv) {
    //Set random number seed
    int payAm = 2200, // earnings for each pay period
        payPd = 26, // how many pay period within a year
        annP = payAm * payPd; //annual pay
    //Declare Variables
    
    //Initialize Variables
    
    //Map/process the Inputs-> Outputs
    
    //Display Inputs/Outputs
    cout <<"Having earned $"<<payAm<<" for "<<payPd;
    cout <<" pay periods, the employee's annual pay is $"<<annP<<endl;
    //Clean up memory and files
    
    //Exit the program
    return 0;
}


