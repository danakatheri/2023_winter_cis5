
/* 
 * File:   main.cpp
 * Author: danak
 * Created on January 9, 2023, 2:38pm
 * Purpose: Create a Banner Letter
 * 
 */
//System Lib

#include <iostream> //Input Output Library

using namespace std;

//User LIBRARIES
 
 //Global Constants not Variables

//Science, Math, Conversions, Dimensions

//Function Prototypes

//Execution begins here at main
int main(int argc, char** argv) {
     //Set random number seed
    
    //Declare Variables
    char lt; // Letter to Create Banner Character
    //Initialize Variables
    cout<< "Type in a letter to compose the Banner C" <<endl;
    cout<< "use character a-z, or A-Z"<<endl;
    cin>>lt;
    //Map/process the Inputs-> Outputs
    
    //Display Inputs/Outputs
    cout<<"  "<<lt<<lt<<lt<<endl;
    cout<<" "<<lt<<"  "<<lt<<endl;
    cout<<lt<<endl;
    cout<<lt<<endl;
    cout<<lt<<endl;
    cout<<lt<<endl;
    cout<<lt<<endl;
    cout<<lt<<endl;
    cout<<" "<<lt<<"  "<<lt<<endl;
    cout<<"  "<<lt<<lt<<lt<<endl;
    //Clean up memory and files
    
    //Exit the program
    return 0;
}