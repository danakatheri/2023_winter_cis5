
/* 
 * File:   main.cpp
 * Author: danak
 * Created on January 9, 2023, 9:13 PM
 * Purpose: Programming Challenges
 * 
 */
//Sum of Two Numbers

#include <iostream> //Input Output Library

using namespace std;
//User LIBRARIES
 
 //Global Constants not Variables

//Science, Math, Conversions, Dimensions

//Function Prototypes

//Execution begins here at main

int main(int argc, char** argv) {
    
  
    int a = 50;
    int b = 100;
    int total = a + b;
    
    cout << a << "+" << b << "=" << total << endl;
   
    return 0;
}